import 'package:flutter/material.dart';

const kblue = Colors.blue;
const kLogo =
    'https://i.ibb.co/fYM0Pf4j/Zeus-Face-f70b098e-removebg-preview.png';
